#include <iostream>
#include <ctime>
#include <cstdlib>
//#include <ncurses.h>
#include "../include/functions.hpp"
using namespace std;

//  usleep(time);
// Le va a servir para que no se imprima todo de una vez, si no poco a poco, lo mete dentro del for que imprime


int Modulo(int iN, int iMod) {
	int iQ = (iN/iMod);
	return iN - (iQ*iMod);
}

char Char(int iGenerator, char cBase, int iRange) {
	return (cBase + Modulo(iGenerator, iRange));
}

int main() {
	char caRow[80]; //Gebera un arreglo de characters
	int j = 6; //Parametro para los characters ASCII
	int k = 1; //Parametro para los characters ASCII
	int l = 4; //Parametro para los characters ASCII
	int m = 2; //Parametro para los characters ASCII
	bool tf;
	tf=true;
	//Va a correr indefinidamente la matrix
	while (tf) {
		int i = 0;
		//
		while (i < 80) {
			if (caRow[i] != ' ') {
				caRow[i] = Char(j + i*i, 33, 30);
			}
			std::cout << caRow[i];
			++i;
		}
		j = (j + 31);
		k = (k + 17);
		l = (l + 47);
		m = (m + 67);
		caRow[Modulo(j, 80)] = '-';
		caRow[Modulo(k, 80)] = ' ';
		caRow[Modulo(l, 80)] = '-';
		caRow[Modulo(m, 80)] = ' ';
		// Delay
		i = 0;
		while (i < 1) {
			Char(1, 1, 1);
			 ++i;
		}
		//tf=false;
	}
		ClearScreen();
    return 0;
}


//se compila así: g++ archivo.cpp -o nombre
