#include <iostream>
#include <ctime>
#include <cstdlib>
//#include <ncurses.h>
#include "../include/functions.hpp"
using namespace std;


void ClearScreen()
  {
  cout << string( 100, '\n' );
  }

  void moveScreen();

  void printScreen();



  void wait(unsigned int time);
