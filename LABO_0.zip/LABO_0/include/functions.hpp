#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

void ClearScreen();

void moveScreen();

void printScreen();

void wait(unsigned int time);
